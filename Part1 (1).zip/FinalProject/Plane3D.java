/*
 * Point3D (x,y,z) - creates a 3D plane object
 * @author Vishal Bhat
 *
*/ 
public class Plane3D {
    private double a;
    private double b;
    private double c;
    private double d;
    private Point3D p1;
    private Point3D p2;
    private Point3D p3;
    
    // Constructor: constructs plane with 3 points as params
    public Plane3D(Point3D p1, Point3D p2, Point3D p3){
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }
    public Plane3D(double a, double b, double c, double d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    // @param: Point3D - the point we are finding the distance from
    // gets the euclidean distance between a point and plane
    public double distance(Point3D pt) {
        d = Math.abs((a * pt.getX() + b * pt.getY() + c * pt.getZ() + d));
        float e = (float)Math.sqrt(a * a + b * b + c * c);
        return d/e;
     }
}
