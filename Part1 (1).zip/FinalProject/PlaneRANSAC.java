/** 
 * Vishal Bhat
 * SN
 * CSI 2120
 *
 * This is the class that runs the Ransac algorithm.
 *
 * @author Vishal Bhat
 */
import java.io.*;
import java.util.*;
public class PlaneRANSAC {
    private PointCloud pc;
    private double eps;
    private double support = 0;
    private int curr = 0;
    private Iterator<Point3D> it;
    private Plane3D dom; 
    private Point3D d1;
    private Point3D d2;
    private Point3D d3;

    //constructs a Planeransac object with param PointCloud object pc
    public PlaneRANSAC(PointCloud pc){
        this.pc = pc;
    }
    //setter method for eps
    public void setEps(double eps){
        eps = 0.1;
    }
    //getter method for eps
    public double getEps(){
        return eps;
    } 
    
    //getter method for num of iterations
    public int getNumberOfIterations(double confidence, double percentageOfPointsOnPlane) {
        double k = Math.log( 1 - confidence ) / Math.log(1 -(percentageOfPointsOnPlane*percentageOfPointsOnPlane*percentageOfPointsOnPlane));
        return (int)(Math.ceil(k));
    }
    //runs Ransac algorithm
    public void run(int numberOfIterations, String filename) throws FileNotFoundException, UnsupportedEncodingException {
        for(int y = 0; y < 3; y++) {
            for(int x = 0; x < numberOfIterations; x++){
            
                Point3D p1 = pc.getPoint();
                Point3D p2 = pc.getPoint();
                Point3D p3 = pc.getPoint();
                double a1 = p2.getX() - p1.getX();
                double b1 = p2.getY() - p1.getY();
                double c1 = p2.getZ() - p1.getZ();
                double a2 = p3.getX() - p3.getX();
                double b2 = p3.getY() - p3.getY();;
                double c2 = p3.getZ() - p3.getZ();;
                double a = b1 * c2 - b2 * c1;
                double b = a2 * c1 - a1 * c2;
                double c = a1 * b2 - b1 * a2;
                double d = (- a * p1.getX() - b * p1.getY() - c * p1.getZ());
                Plane3D plane = new Plane3D(a,b,c,d);
                it = pc.Iterator();
                while(it.hasNext()) {
                    Point3D p = it.next();
                    if (plane.distance(p) < eps) {
                        curr++;
                    }
                }
                if (curr > support) {
                    support = curr;
                    d1 = p1;
                    d2 = p2;
                    d3 = p3;
                    dom = plane;
                    curr = 0;
                    System.out.println(d1 + "" + d2 + "" + d3);
                } 
                it = pc.Iterator(d1,d2,d3);
                pc.save(filename,d1,d2,d3);
            }

        }

        
    }

 }

