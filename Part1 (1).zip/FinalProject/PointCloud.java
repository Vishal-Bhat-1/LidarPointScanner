/*
 * PointCloud - Creates a PointCloud object that contains all of the points
 * @author Vishal Bhat
 *
*/ 
import java.io.*;
import java.util.*;
public class PointCloud {
    private String filename;
    private List<Point3D> points =  new ArrayList<Point3D>();
    private List<Point3D> dominant =  new ArrayList<Point3D>();

    //Constructs a PointCloud object and requires the filename parameter
    public PointCloud(String filename){
        this.filename = filename;
    }
    public PointCloud(){}

    //adds the given point (param) to the text file
    public void addPoint(Point3D pt) throws FileNotFoundException {
        
        File myObj = new File(filename);
        //java forces a try catch since scanner throws file not found errors
        Scanner reader = new Scanner(myObj);
        //first line should have column names
        reader.nextLine();
        //scan through file
        while (reader.hasNextLine()) {
            //get next line and split into x,y,z
            String[] tokens = reader.nextLine().split(",");
            //make into point
            Point3D p = new Point3D(
            Double.parseDouble(tokens[0]), 
            Double.parseDouble(tokens[1]), 
            Double.parseDouble(tokens[2])
            );
            //add point to list
            points.add(p);
        }
        reader.close();
    }

    //gets a random point
    public Point3D getPoint() {
        int index = (int)(Math.random() * points.size());
        return points.get(index);
    }

    //getter method that returns the list of points in pointcloud
    public List<Point3D> getPoints() {
        return points;
    }

    //saves the points as a txt file
    public void save(String filename, Point3D d1, Point3D d2, Point3D d3) throws FileNotFoundException, UnsupportedEncodingException {
        PrintWriter writer = new PrintWriter(filename, "UTF-8");
        writer.println("x,y,z");
    
        String xyz = d1.getX()+","+d1.getY()+","+d1.getZ()+",";
        writer.println(xyz);
        xyz = d2.getX()+","+d2.getY()+","+d2.getZ()+",";
        writer.println(xyz);
        xyz = d3.getX()+","+d3.getY()+","+d3.getZ()+",";
        writer.println(xyz);
        writer.close();
    }

    //iterator that iterates through a list of points
    public Iterator<Point3D> Iterator(){
        Iterator<Point3D> it = points.iterator();
        return it;
    }

    //iterator that iterates through a list of points and removes the given points (parameter)
    public Iterator<Point3D> Iterator(Point3D d1, Point3D d2, Point3D d3){
        Iterator<Point3D> it = points.iterator();
        while(it.hasNext()) {
            Point3D p = it.next();
            if(p.equals(d1) || p.equals(d2) || p.equals(d3)) {
                    it.remove();
                }
            }
        return it;
    }

}
